# Full-Stack Application Submission

**Project:** League Guide  
**Live application link:** Add your Render link here after deployment: `https://your-app-name.onrender.com`

## Project summary

League Guide is a responsive full-stack website that provides simple League of Legends champion tips. Visitors can view published guides, open an individual guide preview, find contact information, and submit a champion suggestion. The application also includes secure session-based admin authentication. After logging in, an administrator can add new guides, edit existing information, preview unpublished drafts, publish content, or delete guides. The back end is built with Node.js and Express, the pages use EJS templates, and the application stores its content in a server-side JSON file. The layout adjusts for desktop and mobile screens.

## Requirement checklist

- User login and authentication: Admin email/password login with protected sessions
- Admin features: Add, edit, preview, publish, and delete champion guides
- Contact information: Email, phone number, office location, and contact form
- Public preview page: Public event list and individual event pages
- Responsive design: Mobile-friendly navigation, forms, tables, and event cards
