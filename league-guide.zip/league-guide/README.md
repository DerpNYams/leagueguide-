# League Guide

League Guide is a simple full-stack League of Legends champion guide website. Visitors can browse public guides and send a contact message. An authenticated administrator can add, edit, preview, publish, and delete guides from a protected dashboard.

## Features

- Admin login with password hashing and session authentication
- Protected admin dashboard
- Create, edit, preview, publish, and delete champion guides
- Public guide listing and individual preview pages
- Contact information and a working contact form
- Responsive layout for desktop, tablet, and mobile
- JSON data storage that starts with sample content

## Run locally

1. Install Node.js 18 or newer.
2. Open this folder in Visual Studio Code.
3. Open the terminal and run `npm install`.
4. Copy `.env.example` to `.env` if you want to change the login settings.
5. Run `npm start`.
6. Open `http://localhost:3000`.

The default local admin login is:

- Email: `admin@leagueguide.com`
- Password: `ChangeMe123!`

Change these values before publishing.

## Publish on Render

1. Upload this folder to a new GitHub repository.
2. Sign in to [Render](https://render.com) and choose **New > Web Service**.
3. Connect the GitHub repository.
4. Use `npm install` as the build command and `npm start` as the start command.
5. Add environment variables for `SESSION_SECRET`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD`.
6. Deploy, then copy the generated `https://...onrender.com` address into `SUBMISSION.md`.

The included `render.yaml` can also be used as a Render Blueprint. On a free web service, local JSON data can reset after a restart or redeploy. That is acceptable for a class demonstration; a longer-term version should use Render Postgres or another hosted database.

## Maintenance

- Update dependencies with `npm update` and run `npm test` afterward.
- Use a strong admin password and secret in production.
- Check the admin dashboard for event drafts and contact messages.
- Back up `data/content.json` if using this version outside a demo.

## Test

Run `npm test` to check the public page, authentication protection, admin login, and contact form.
